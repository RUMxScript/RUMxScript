SimpleSpy V3
